import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, GeoJSON } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// RATPロゴをアイコンとして設定
const userIcon = new L.Icon({
  iconUrl:
    "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/RATP_logo_2019.svg/256px-RATP_logo_2019.svg.png",
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
});

// サンプル路線GeoJSON（仮データ）
const metroLineSample = {
  type: "Feature",
  geometry: {
    type: "LineString",
    coordinates: [
      [2.3522, 48.8566],
      [2.3600, 48.8600],
      [2.3700, 48.8650],
    ],
  },
  properties: {
    name: "Metro Line 1",
  },
};

export default function ParisMetroApp() {
  const [position, setPosition] = useState([48.8566, 2.3522]); // パリ中心
  const [userLocation, setUserLocation] = useState(null);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // ユーザー位置取得
  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation([pos.coords.latitude, pos.coords.longitude]);
      },
      (err) => {
        console.warn("位置情報取得に失敗", err);
      }
    );
  }, []);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  return (
    <div className={\`h-screen w-screen \${isDarkMode ? "bg-black text-white" : "bg-white text-black"}\`}>
      <header className="bg-blue-800 text-white p-4 text-xl font-bold text-center flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/RATP_logo_2019.svg/256px-RATP_logo_2019.svg.png"
            alt="RATP logo"
            className="h-8"
          />
          パリ メトロ・トラム ライブビュー
        </div>
        <button
          onClick={toggleDarkMode}
          className="bg-white text-blue-800 px-3 py-1 rounded shadow hover:bg-gray-200"
        >
          {isDarkMode ? "ライトモード" : "ダークモード"}
        </button>
      </header>

      <MapContainer center={position} zoom={13} className="h-[85%] w-full">
        <TileLayer
          url={
            isDarkMode
              ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          }
          attribution="&copy; OpenStreetMap contributors"
        />

        {/* ユーザー位置表示（RATPロゴアイコン） */}
        {userLocation && (
          <Marker position={userLocation} icon={userIcon}>
            <Popup>あなたの現在地</Popup>
          </Marker>
        )}

        {/* 地下鉄路線の表示（仮） */}
        <GeoJSON data={metroLineSample} style={{ color: "#0077c2", weight: 4 }} />
      </MapContainer>

      {/* Travic埋め込み（仮） */}
      <div className="w-full text-center p-2 text-sm bg-gray-100 dark:bg-gray-800">
        <a
          href="https://www.travic.app/?zoom=13&center=48.8566,2.3522&layer=1"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 underline"
        >
          Travicでリアルタイムなパリ交通を表示（外部リンク）
        </a>
      </div>
    </div>
  );
}
